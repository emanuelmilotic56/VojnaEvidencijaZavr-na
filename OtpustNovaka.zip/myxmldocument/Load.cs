﻿namespace myxmldocument
{
    internal class Load
    {
    }
}